import os
from PIL import Image

my_directory = os.chdir("./")
imgs_files = os.listdir(my_directory)

output_directory = "./generated_images"
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

for file in imgs_files:
    if ".jpg" in file:
        f_name, f_ext = os.path.splitext(file)
        try:
            with Image.open(file) as img:
                print(img)
                w_size, h_size = img.size
                print(w_size, h_size)
                new_width = int(w_size*5)
                new_height = int(h_size*5)
                output_path = os.path.join(output_directory, f_name + ".jpeg")
                img.convert("RGB").resize((new_width, new_height)).save(output_path, "JPEG")
                # print("processing"+ file)
        except OSError:
            print("cannot convert", file)